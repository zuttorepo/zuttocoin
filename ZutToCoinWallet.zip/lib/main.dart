import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(ZutToWalletApp());
}

class ZutToWalletApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ZutToCoin Wallet',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.amber,
        scaffoldBackgroundColor: Colors.black,
      ),
      home: WalletHomePage(),
    );
  }
}

class WalletHomePage extends StatelessWidget {
  final TextEditingController addressController = TextEditingController();
  final TextEditingController amountController = TextEditingController();

  void _sendTransaction(BuildContext context) {
    final address = addressController.text;
    final amount = amountController.text;

    if (address.isEmpty || amount.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Alamat dan jumlah harus diisi")),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Transaksi Berhasil"),
        content: Text("Mengirim $amount ZUT ke $address"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          )
        ],
      ),
    );

    addressController.clear();
    amountController.clear();
  }

  void _receiveAddress(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Alamat Wallet Anda"),
        content: SelectableText("zutto1yourwalletaddresshere"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Salin"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ZutToCoin Wallet"),
        centerTitle: true,
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: addressController,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Alamat Tujuan",
                labelStyle: TextStyle(color: Colors.amber),
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: amountController,
              style: TextStyle(color: Colors.white),
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Jumlah ZUT",
                labelStyle: TextStyle(color: Colors.amber),
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  onPressed: () => _sendTransaction(context),
                  icon: Icon(Icons.send),
                  label: Text("Kirim"),
                  style: ElevatedButton.styleFrom(primary: Colors.amber),
                ),
                ElevatedButton.icon(
                  onPressed: () => _receiveAddress(context),
                  icon: Icon(Icons.qr_code),
                  label: Text("Terima"),
                  style: ElevatedButton.styleFrom(primary: Colors.amber),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
